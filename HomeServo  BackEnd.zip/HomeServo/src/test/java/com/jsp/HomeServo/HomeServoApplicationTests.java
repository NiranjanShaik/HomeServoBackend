package com.jsp.HomeServo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HomeServoApplicationTests {

	@Test
	void contextLoads() {
	}

}
