package com.jsp.HomeServo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.HomeServo.dto.Work;
import com.jsp.HomeServo.service.WorkService;
import com.jsp.HomeServo.util.ResponseStructure;

import io.swagger.annotations.ApiOperation;

@RestController
public class WorkController {
	@Autowired
	WorkService service;
	
	@PostMapping("/savework/{cus_id}")
	@CrossOrigin
	
	@ApiOperation(value = "api for save work details")
	public ResponseEntity<ResponseStructure<Work>> saveWork(@RequestBody Work work,@PathVariable int cus_id){
		return service.saveWork(work, cus_id);
	}
	
	@GetMapping("/updatework/{id}")
	@CrossOrigin
	@ApiOperation(value = "api for get work details by using id ")
	public ResponseEntity<ResponseStructure<Work>> getWorkById(@PathVariable int id){
		return service.getWorkById(id);
	}
	
	@PutMapping("/startdate/{w_id}/{v_id}")
	@CrossOrigin
	@ApiOperation(value = "api for start date using work id and vendor id")
	public ResponseEntity<ResponseStructure<Work>> startDate(@PathVariable int w_id, @PathVariable int  v_id){
		return service.startDate(w_id, v_id);
	}
	
	@PutMapping("/enddate/{w_id}/{v_id}")
	@CrossOrigin
	@ApiOperation(value = "api for start date using work id and vendor id")
	public ResponseEntity<ResponseStructure<Work>> endDate(@PathVariable int w_id,@PathVariable int v_id){
		return service.endDate(w_id, v_id);
	}
	
	@GetMapping("/getallwork/{v_id}")
	@CrossOrigin
	@ApiOperation(value = "api for get all the works")
	public ResponseEntity<ResponseStructure<List<Work>>> getAllWorks(@PathVariable int v_id){
		return service.listOfWork(v_id);
	}
	

}
