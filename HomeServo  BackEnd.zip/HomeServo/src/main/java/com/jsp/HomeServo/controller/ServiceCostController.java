package com.jsp.HomeServo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.HomeServo.dto.ServiceCost;
import com.jsp.HomeServo.service.ServiceCostService;
import com.jsp.HomeServo.util.ResponseStructure;

import io.swagger.annotations.ApiOperation;

@RestController
public class ServiceCostController {
	@Autowired
	ServiceCostService service;
	
	@PostMapping("/savecost/{v_id}/{w_id}")
	@CrossOrigin
	@ApiOperation(value = "api for saving cost")
	public ResponseEntity<ResponseStructure<ServiceCost>> saveCost(@PathVariable int v_id, @PathVariable int w_id){
		return service.saveCost(w_id, v_id);
	}
	
	@PutMapping("/payment/{c_id}")
	@CrossOrigin
	@ApiOperation(value = "api for make payment")
	public ResponseEntity<ResponseStructure<ServiceCost>> payment(@PathVariable int c_id, @RequestBody ServiceCost cost){
		return service.payment(c_id, cost);
	}
}
