package com.jsp.HomeServo.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.HomeServo.dto.Customer;
import com.jsp.HomeServo.duplicate.DummyCustomer;
import com.jsp.HomeServo.service.CustomerService;
import com.jsp.HomeServo.util.ResponseStructure;

import io.swagger.annotations.ApiOperation;

@RestController
public class CustomerController {
	@Autowired
	private CustomerService service;
	
	@PostMapping("/savecustomer")
	@CrossOrigin
	@ApiOperation(value = "api for saving customer")
	public ResponseEntity<ResponseStructure<Customer>> saveCustomer(@RequestBody Customer customer) {
		return service.saveCustomer(customer);
	}
	@PutMapping("/updatecustomer")
	@CrossOrigin
	@ApiOperation(value = "api for update customer")
	public ResponseEntity<ResponseStructure<Customer>> updateCustomer(@RequestBody Customer customer) {
		return service.updateCustomer(customer);
	}
	
	@GetMapping("/getcustomerbyid/{id}")
	@CrossOrigin
	@ApiOperation(value = "api for get customer by id")
	public ResponseEntity<ResponseStructure<DummyCustomer>> getCustomerById(@PathVariable int id) {
		return service.getCustomerById(id);
	}
	@GetMapping("/logincustomer/{email}/{pwd}")
	@CrossOrigin
	@ApiOperation(value = "api for customer login")
	public ResponseEntity<ResponseStructure<Customer>> login(@PathVariable String email,@PathVariable String pwd){
		System.out.println(12);
		return service.login(email, pwd);
	}
	
	@DeleteMapping("/deletecustomer/{id}")
	@CrossOrigin
	@ApiOperation(value = "api for delete customer details")
	public ResponseEntity<ResponseStructure<Customer>> deleteCustomer(@PathVariable int id){
		return service.deleteCustomer(id);
	}
	
	
}
