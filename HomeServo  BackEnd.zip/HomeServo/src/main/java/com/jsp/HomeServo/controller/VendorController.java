package com.jsp.HomeServo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.HomeServo.dto.Vendor;
import com.jsp.HomeServo.service.VendorService;
import com.jsp.HomeServo.util.ResponseStructure;

import io.swagger.annotations.ApiOperation;

@RestController
public class VendorController {
	@Autowired
	VendorService service;
	
	@PostMapping("/savevendor")
	@CrossOrigin
	@ApiOperation(value = "api for save vendor details")
	public ResponseEntity<ResponseStructure<Vendor>> saveVendor(@RequestBody Vendor vendor) {
		return service.saveVendor(vendor);
	}
	
	@PutMapping("/updatevendor")
	@CrossOrigin
	@ApiOperation(value = "api for update vendor details")
	public ResponseEntity<ResponseStructure<Vendor>> updateVendor(@RequestBody Vendor vendor) {
		return service.updateVendor(vendor);
	}
	
	@GetMapping("/getvendorbyid/{id}")
	@CrossOrigin
	@ApiOperation(value = "api for get vendor details by using id")
	public ResponseEntity<ResponseStructure<Vendor>> getVendorById(@PathVariable int id){
		return service.getVendorById(id);
	}
	
	@GetMapping("/loginvendor/{email}/{pwd}")
	@CrossOrigin
	@ApiOperation(value = "api for vendor login")
	public ResponseEntity<ResponseStructure<Vendor>> login(@PathVariable String email,@PathVariable String pwd){
		return service.login(email, pwd);
	}
	
	@DeleteMapping("/deletevendor/{id}")
	@CrossOrigin
	@ApiOperation(value = "api for delete vendor details")
	public ResponseEntity<ResponseStructure<Vendor>> deleteVendor(@PathVariable int id){
		return service.deleteVendor(id);
	}
	
	@GetMapping("/getallvendor/{c_id}")
	@CrossOrigin
	@ApiOperation(value = "api for get all vendors")
	public ResponseEntity<ResponseStructure<List<Vendor>>> getAllVendor(@PathVariable int c_id){
		return service.getAllVendor(c_id);
	}

}
